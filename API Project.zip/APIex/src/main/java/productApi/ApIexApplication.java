package productApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
@ComponentScan("productApi")
@EntityScan("productApi")
public class ApIexApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApIexApplication.class, args);
	}

}
